from agents.planner_agent import PlannerAgent
from agents.content_agent import ContentAgent

planner = PlannerAgent()
content = ContentAgent()

def run_pipeline(task):
    steps = planner.run(task)
    article = content.generate(task)

    return {
        "steps": steps,
        "content": article
    }
