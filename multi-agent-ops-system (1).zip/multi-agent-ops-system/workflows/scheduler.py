import time

def start_scheduler():
    while True:
        print("Workflow running...")
        time.sleep(5)
