class ContentAgent:
    def generate(self, topic):
        return f"AI generated content about {topic}"
