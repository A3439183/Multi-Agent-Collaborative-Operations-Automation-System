class ResearchAgent:
    def analyze(self, keyword):
        return {
            "keyword": keyword,
            "trend": "High"
        }
