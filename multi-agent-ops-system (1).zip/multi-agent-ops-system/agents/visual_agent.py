class VisualAgent:
    def generate_prompt(self, topic):
        return f"Generate cinematic visual for {topic}"
