class PlannerAgent:
    def run(self, task):
        return {
            "task": task,
            "steps": [
                "Analyze topic",
                "Generate strategy",
                "Create content",
                "Review quality"
            ]
        }
