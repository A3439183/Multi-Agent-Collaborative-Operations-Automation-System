class ReviewAgent:
    def review(self, content):
        return {
            "score": 92,
            "status": "approved"
        }
