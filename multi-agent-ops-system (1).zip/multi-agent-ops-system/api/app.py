from fastapi import FastAPI
from workflows.pipeline import run_pipeline

app = FastAPI()

@app.get("/")
def home():
    return {
        "project": "Multi-Agent Ops System",
        "status": "running"
    }

@app.get("/run")
def run(task: str):
    return run_pipeline(task)
